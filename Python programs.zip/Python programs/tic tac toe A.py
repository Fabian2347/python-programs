# | |  0
#----- 1
# | |  2
#----- 3
# | |  4
#01234

def drawField(field):
    for row in range(5): #0,1,2,3,4
        if row%2 == 0:
            for column in range(5): #0,1,2,3,4
                if column%2 == 0:
                    if column != 4:
                        print(" ",end ="")
                    else:
                        print(" ") 
                else:
                    print("|",end = "")
        else:
            print("-----")
Player = 1
currentField = [[" "," "," "], [" "," "," "], [" "," "," "]] #columns
print(currentField)
while(True): #infinite loop
    print("Players turn: ",Player)
    MoveRow = int(input("Please enter the row\n "))
    MoveColumn = int(input("Please enter the column\n "))
    if Player == 1:
        # make move for player 1
        currentField[MoveColumn][MoveRow] = "X"
        Player = 2
    else:
        # make move for player 2
        currentField[MoveColumn][MoveRow] = "O"
        Player = 1
    print(currentField )
