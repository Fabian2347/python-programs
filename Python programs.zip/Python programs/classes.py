# class ClassName:
    
#     def __init__(self):              # this function initialize all the attributes the class will have. self is refering always to itself so it'll it's own attributes
#         self.Attribute = 0

#     def AnotherFunction(self):
#         Action 



class Team:
    def __init__(self,Name="Name",Origin = "Origin"):     #Name = "Name" if there is no name, give it the default value
        self.TeamName = Name
        self.TeamOrigin = Origin  

    def DefineTeamName(self,Name):
        self.TeamName = Name 

    def DefineTeamOrigin(self,Origin):
        self.TeamOrigin = Origin 

Team1 = Team("Tigers","USA") 
Team2 = Team("Hawks","NYC")
Team3 = Team()

print(Team1.TeamName) 
Team1.DefineTeamName("Dolphin")   
print(Team1.TeamName) 
print(Team1.TeamOrigin)
Team1.DefineTeamOrigin("USA")
print(Team2.TeamName) 
print(Team2.TeamOrigin)  
print(Team3.TeamName)
print(Team3.TeamOrigin)
