ParticipantNumber = 5       #Nr. of participant allowed to register
ParticiapantData = []       #list of participant data
outputFile = open("ParticipantData.txt","w")

registeredParticiapants = 0
while (registeredParticiapants < ParticipantNumber):
    tempPartData = []   #name,country,age of part
    name = input("Please enter your name: ") 
    tempPartData.append(name) 
    country = input("Please enter your country of origin: ")
    tempPartData.append(country)
    age = int(input("Please enter your age: ")) 
    tempPartData.append(age) 
    print(tempPartData)
    ParticiapantData.append(tempPartData) #append the whole tempPartData
    print(ParticiapantData) 
    registeredParticiapants += 1  #increment by 1 the number


for participant in ParticiapantData:        #temp value for participant that take one by one
    for data in participant: 
        outputFile.write(str(data))     #convert from int to string
        outputFile.write(" ") #Fabian Italy 23 ;add space in the file  
    outputFile.write("\n")      #new line    

outputFile.close()

# READ FILE
inputFile = open("ParticipantData.txt","r") 

inputList = []  #store the data we are gonna read

for line in inputFile:       #line contain each line in the file
    tempParticipant = line.strip("\n").split()          #var to store temp data for part
#    print(tempParticipant)
    inputList.append(tempParticipant)
#    print(inputList)
    # "Max US 21 \n" .strip("\n") -> "Max US 21 "  remove the selected element in bracket
    # "Max US 21 ".split() -> ["Max","US","21"]  every time there is a space it count as a element and put them in list

Age = {}        #empty dictionary
for part in inputList:      #check if the age is already there
    tempAge = int(part[-1])     #int('21') -> 21 turn to int
    if tempAge in Age:     
        Age[tempAge] += 1
    else:
        Age[tempAge] = 1  

print(Age)

Oldest = 0  #there is no age under 0 
Youngest = 100
mostOccuringAge = 0 
counter = 0

for tempAge in Age:
    if tempAge > Oldest:
        Oldest = tempAge
    if tempAge < Youngest:
        Youngest = tempAge
    if Age[tempAge] > counter:
        counter = Age[tempAge]
        mostOccuringAge = tempAge

print("The oldest age is: ",Oldest)
print("The youngest age is: ",Youngest)
print("The most occuring age is:",mostOccuringAge,"with",counter,"participants")

inputFile.close()
