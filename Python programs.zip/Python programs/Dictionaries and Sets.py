#Sets = {"Element1","Element2","Element1","Element4"}
#print(Sets)  #In Sets we don't care about the order, we care if it is there or not. Doesn't repeat the elements if appear more then once
#if "Element1" in Sets:
#    print("yes")


CountryList = []
for i in range (5):
    Country = input("Please enter your country: ")
    CountryList.append(Country)

#CountrySet = set(CountryList)
#print(CountryList)
#print(CountrySet)

#if "Greece" in CountrySet:
#    print("attended")


#Dictionary = {"Key":"Value","Key2":"Value2","Key3":"Value3"}
              #Key = Country  Value: No. of repetition
CountryDictionary = {}
for Country in CountryList:
    if Country in CountryDictionary:
        CountryDictionary[Country] += 1
    else:
        CountryDictionary[Country] = 1
print(CountryDictionary)


